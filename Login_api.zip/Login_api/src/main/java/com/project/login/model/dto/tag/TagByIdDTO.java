package com.project.login.model.dto.tag;

import lombok.Data;


@Data
public class TagByIdDTO {
    private Long tagId;
}
