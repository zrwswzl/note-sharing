package com.project.login.model.dto.notespace;

import lombok.Data;

@Data
public class NoteSpaceByUserDTO {
    private Long userId;
}
