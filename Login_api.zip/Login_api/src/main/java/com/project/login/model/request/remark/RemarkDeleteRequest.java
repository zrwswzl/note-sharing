package com.project.login.model.request.remark;

import lombok.Data;

@Data
public class RemarkDeleteRequest {
    private String id;
}
