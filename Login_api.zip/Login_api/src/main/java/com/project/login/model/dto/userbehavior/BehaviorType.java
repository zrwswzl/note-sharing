package com.project.login.model.dto.userbehavior;

public enum BehaviorType {
    VIEW,
    LIKE,
    FAVORITE,
    COMMENT
}
