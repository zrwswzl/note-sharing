package com.project.login.model.event;

public enum NoteActionType {
    CREATE,
    UPDATE,
    DELETE,
    READ,
    FAVORITE;
}