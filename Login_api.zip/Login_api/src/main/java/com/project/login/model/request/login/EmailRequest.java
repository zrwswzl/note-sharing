package com.project.login.model.request.login;

import lombok.Data;

@Data
public class EmailRequest {
    private String email;
}

