package com.project.login.model.vo;

import lombok.Data;

@Data
public class TagVO {
    Long id;
    String tagName;
}
