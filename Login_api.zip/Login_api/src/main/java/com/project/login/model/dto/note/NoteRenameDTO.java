package com.project.login.model.dto.note;

import lombok.Data;

@Data
public class NoteRenameDTO {

    private Long id;
    private String newName;
}
