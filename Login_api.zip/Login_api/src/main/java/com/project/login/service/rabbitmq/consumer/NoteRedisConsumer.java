package com.project.login.service.rabbitmq.consumer;

public class NoteRedisConsumer {
}
