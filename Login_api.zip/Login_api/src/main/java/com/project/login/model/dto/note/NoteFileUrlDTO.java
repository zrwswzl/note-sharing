package com.project.login.model.dto.note;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NoteFileUrlDTO {
    private String filename;
}