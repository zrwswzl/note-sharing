package com.project.login.model.dto.notespace;

import lombok.Data;

@Data
public class NoteSpaceUpdateDTO {
    private Long id;
    private String name;
    private String tag;
}
