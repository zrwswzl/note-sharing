package com.project.login.model.dto.notespace;

import lombok.Data;

@Data
public class NoteSpaceDeleteDTO {
    private Long id;
}
