package com.project.login.model.request.remark;

import lombok.Data;

@Data
public class RemarkSelectByNoteRequest {
    private Long noteId;
}
