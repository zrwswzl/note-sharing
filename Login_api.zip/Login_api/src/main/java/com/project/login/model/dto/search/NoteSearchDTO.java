package com.project.login.model.dto.search;

import lombok.Data;

@Data
public class NoteSearchDTO {
    private String keyword;
}
